<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class EmPmodel extends CI_Model {

	public function __construct()
	{
		$this->load->database();
	}
	
	public function insert_employee_details($data)
	{
		$ins=$this->db->insert_batch('tbl_employee_details', $data);//echo $this->db->last_query();exit;
		if($ins) return $this->db->insert_id();
		else return 0;
	}
	
	public function GetEmpDetails()
   {
		$this->db->select('name,employee_code,department,date_of_birth,date_of_joining');
		$this->db->from('tbl_employee_details');
		$query = $this->db->get();//echo $this->db->last_query();exit;
        $array= $query->result_array();
		return $array;
   }
}
?>