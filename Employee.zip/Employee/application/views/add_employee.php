<!DOCTYPE html>
<html>
   <head>
     <title>Employee Data Book</title>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     
     
     <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    
     
     
      <style>
      .table tbody tr th
      {
        min-width: 200px;
      }
      .table tbody tr td
      {
        min-width: 200px;
      }
      </style>
   </head>
   <body>
    <div class="container">
     <br />
     <br />
      <h3 align="center">The Employee Information System</h3>
      <br />
        <div id="message"></div>
      	<div class="panel panel-default">
          <div class="panel-body">
           <div  style="display:none;" id="AdEmpdiv"> 
            <div class="row" id="upload_area">
                  <form method="post" id="upload_form" enctype="multipart/form-data">
                        <div class="col-md-6" align="right">Choose File</div>
                            <div class="col-md-6">
                              <input type="file" name="file" id="csv_file" />
                               <p style="color:#F00;"> Allowded type :-  csv  </p> 
                            </div>
                             <br /><br /><br />
                            <div class="col-md-12" align="center">
                              <input type="submit" name="upload_file" id="upload_file" class="btn btn-primary" value="Upload" />
                            </div>
                  </form>
            </div>
          </div>
          <div class="table-responsive" id="process_area">
          <!--CSV content Displayed here-->
          </div>
            <br/>
            <div class="x_content">
               <div class="row">
                 <div class="col-md-12">
                  <button name="add" id="add" class="btn btn-primary"  onclick="showDiv()"  style="height:41px; width:121px; padding-right:150px; float:right;">Add New Employee</button>
                </div>
                  <p> <br/> <br/><br/> </p>   
                  <div class="col-sm-12">
                    <div class="table-responsive">
             				<?php if(!empty($employeelist)){?>
                                    <table id="example" class="datatable-1 table table-bordered table-striped	 display" style="width:100%">
                                      <thead bgcolor="#1a6892" style="color:#FFF;">
                                        <tr>
                                          <th>Employee Code</th>
                                          <th>Employee name</th>
                                          <th>Department</th>
                                          <th>Age</th>
                                          <th>Experience in the Organization</th>
                                        </tr>
                                      </thead>
                                       <?php $to   = new DateTime('today');
										foreach ($employeelist as $EMPD): ?>
                                      <tbody>
                                        <tr>
                                          <td><?php echo $EMPD['name'];?></td>
                                          <td><?php echo $EMPD['employee_code'];?></td>
                                          <td><?php echo $EMPD['department'];?></td>
                                          <td><?php echo $age = (date('Y') - date('Y',strtotime($EMPD['date_of_birth'])));?></td>
                                           <td><?php echo $exp= (date('Y') - date('Y',strtotime($EMPD['date_of_joining'])))?></td>
                                        </tr>
                                     <?php endforeach; ?>
                                      </tbody>
                                    </table>
                    
                 <?php } else {}?>
                  </div>
                </div>
              </div>
            </div>
            </div>
          </div>
       </div>
     </div>
   </body>
</html>

<script type="text/javascript" >

function showDiv() {
   document.getElementById('AdEmpdiv').style.display = "block";
}
</script>

<script>
$(document).ready(function(){
  $('#upload_form').on('submit', function(event){
    event.preventDefault();
    $.ajax({
	   url:  "<?php echo base_url(); ?>"+"EMp/upload",
      method:"POST",
      data:new FormData(this),
      dataType:'json',
      contentType:false,
      cache:false,
      processData:false,
      success:function(data)
      {
        if(data.error != '')
        {
          $('#message').html('<div class="alert alert-danger">'+data.error+'</div>');
        }
        else
        {
          $('#process_area').html(data.output);
          $('#upload_area').css('display', 'none');
        }
      }
    });
	var btn = document.getElementById('add');
    btn.style.display = 'none';
  });
  var total_selection = 0;
  var name = 0;
  var employee_code = 0;
  var department = 0;
  var date_of_birth = 0;
  var date_of_joining = 0;
  var column_data = [];
  $(document).on('change', '.set_column_data', function(){
    var column_name = $(this).val();
    var column_number = $(this).data('column_number');
    if(column_name in column_data)
    {
      alert('You have already define '+column_name+ ' column');
      $(this).val('');
      return false;
    }
    if(column_name != '')
    {
      column_data[column_name] = column_number;
    }
    else
    {
      const entries = Object.entries(column_data);
      for(const [key, value] of entries)
      {
        if(value == column_number)
        {
          delete column_data[key];
        }
      }
    }

    total_selection = Object.keys(column_data).length;
    if(total_selection == 5)
    {
      $('#import').attr('disabled', false);
      name = column_data.name;
      employee_code = column_data.employee_code;
      department = column_data.department;
	  date_of_birth = column_data.date_of_birth;
	  date_of_joining = column_data.date_of_joining;
    }
    else
    {
      $('#import').attr('disabled', 'disabled');
    }

  });
  $(document).on('click', '#import', function(event){
    event.preventDefault();
    $.ajax({
	   url:  "<?php echo base_url(); ?>"+"EMp/import",
      method:"POST",
      data:{name:name, employee_code:employee_code, department:department,date_of_birth:date_of_birth,date_of_joining:date_of_joining},
      beforeSend:function(){
        $('#import').attr('disabled', 'disabled');
        $('#import').text('Importing...');
      },
      success:function(data)
      {
        $('#import').attr('disabled', false);
        $('#import').text('Import');
        $('#process_area').css('display', 'none');
        $('#upload_area').css('display', 'block');
        $('#upload_form')[0].reset();
        $('#message').html("<div class='alert alert-success'>"+data+"</div>");
		window.location.reload();
      }
    })

  });
  
});
</script>

