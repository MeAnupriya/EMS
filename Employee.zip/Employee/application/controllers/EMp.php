<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EMp extends CI_Controller {

public function __construct(){
        parent::__construct();
		$this->load->library('session');
        $this->load->helper('url');
		$this->load->library('upload');
        $this->load->helper('form');
		$this->load->helper('string');
        $this->load->library('form_validation');
		$this->load->library("pagination");
		$this->load->model('EmPmodel');
}



 public function add_employee()
 {
	$data4page['employeelist']= $this->EmPmodel->GetEmpDetails();
	$this->load->view('add_employee',$data4page);
 }	


// Ajax function

public function upload()
{
	$error = '';
	$html = '';
	if($_FILES['file']['name'] != '')
	{
	  $file_array = explode(".", $_FILES['file']['name']);
	  $extension = end($file_array);
		 if($extension == 'csv')
		 {
		   $file_data = fopen($_FILES['file']['tmp_name'], 'r');
		   $file_header = fgetcsv($file_data);
		   $html .= '<table class="table table-bordered"><tr>';
	  	   for($count = 0; $count < count($file_header); $count++)
	       {
			   $html .= '
			   <th>
				<select name="set_column_data" class="form-control set_column_data" data-column_number="'.$count.'">
				 <option value="">Set Column Data</option>
				 <option value="name">Name</option>
				 <option value="employee_code">Employee Code</option>
				 <option value="department">Department</option>
				 <option value="date_of_birth">Date of birth</option>
				 <option value="date_of_joining">Date of joining</option>
				</select>
			   </th>
			   ';
	      }
         $html .= '</tr>';
         $limit = 0;
				  while(($row = fgetcsv($file_data)) !== FALSE)
				  {
					$limit++;
					   if($limit < 21)
					   {
							$html .= '<tr>';
							for($count = 0; $count < count($row); $count++)
							{
							  $html .= '<td>'.$row[$count].'</td>';
							}
							$html .= '</tr>';
						}
						$temp_data[] = $row;
				 }
		  $_SESSION['file_data'] = $temp_data;
		 $html .= '</table><br /><div align="right"><button type="button" name="import" id="import" class="btn btn-success" disabled>Import</button></div><br />';
     }
	 else
	 {
		  $error = 'Only <b>.csv</b> file allowed';
	 }
   }
	else
	{
	 $error = 'Please Select CSV File';
	}
	$output = array(
	 'error'  => $error,
	 'output' => $html
	);
echo json_encode($output);
}
	
	
public function import()
{
	if(isset($_POST["name"]))
	{
	 $file_data = $_SESSION['file_data'];
	 unset($_SESSION['file_data']);
		 foreach($file_data as $row)
		 {
			 $data4insert[] = array(
						'name' =>  $row[$_POST["name"]],
						'employee_code' =>  $row[$_POST["employee_code"]],
						'department' =>  $row[$_POST["department"]],
						'date_of_birth' =>  date('Y-m-d',strtotime($row[$_POST["date_of_birth"]])),
						'date_of_joining' =>  date('Y-m-d',strtotime($row[$_POST["date_of_joining"]]))
						);
		 }
		 if(isset($data4insert))
		 { 
		    $insert_id	= $this->EmPmodel->insert_employee_details($data4insert); 
			if( $insert_id>0)
			{ 
		      echo 'Data Imported Successfully';
		    }
	     }
    }
 }
	
}
?>